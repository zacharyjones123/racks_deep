# Shopify Product API - https://help.shopify.com/en/api/reference/products/product
# --------------------------------------------------------
# ALL OF THIS IS TO SET UP SHOPIFY API
API_KEY = "a8318ba6ec81130322497e0e213ad1ae"
PASSWORD = "0171e35f0140499ac3b8a19a4ad166d4"
SHARED_SECRET = "3472f87f94cd07d94971db3222da1b87"
SHOP_URL = "https://%s:%s@racks-deep-custom-performance.myshopify.com/admin" % (API_KEY, PASSWORD)