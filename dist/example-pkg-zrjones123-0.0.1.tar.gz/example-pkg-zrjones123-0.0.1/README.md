# racks_deep
This is my project to work with

Sphinx Configuration Notes
- quickstart-sphinx
- sphinx-apidoc -o ./doc ./FolderWithpythonFiles
Then move to the doc file
- clean html
- make html
Note: This took a lot of time to figure out so I saved all of the steps. Hopefully it will be easier from here on out
----------------------
flake8 module
- use flake8 --statistics
-- This will give all of the style errors in the files
------------------------
pip freeze > requirements.txt
-- This will give all of the modules that I have in this project
(great when working on this on multiple computers)
--------------------------